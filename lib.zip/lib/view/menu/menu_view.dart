import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:workoutfitnesstool/common/color_extention.dart';
import 'package:workoutfitnesstool/view/home/home_view.dart';
import 'package:workoutfitnesstool/view/menu/yoga_view.dart';

import '../../common_widget/menu_cell.dart';
import '../../common_widget/plan_row.dart';
import '../weight/weight_view.dart';

class MenuView extends StatefulWidget {
  const MenuView({super.key});

  @override
  State<MenuView> createState() => _MenuViewState();
}

class _MenuViewState extends State<MenuView> {
  List planArr =[{
      "name":"Running",
    "icon":"assets/img/run.png",
    "right_icon": ""
  },
    {
      "name":"Yoga",
      "icon":"assets/img/yoga.png",
      "right_icon": "assets/img/information.png"
    },
    {
      "name":"Workout",
      "icon":"assets/img/work.png",
      "right_icon": ""
    },
    {
      "name":"Walking",
      "icon":"assets/img/walk.png",
      "right_icon": ""
    },
    {
      "name":"Fitness",
      "icon":"assets/img/fitness.png",
      "right_icon": "assets/img/information.png"
    },
    {
      "name":"Strength",
      "icon":"assets/img/strength.png",
      "right_icon": ""
    }



  ];

  List menuArr = [
    {"name":"Home", "image":"assets/img/home.png", "tag": "1",},
    {"name":"Weight", "image":"assets/img/scale.png", "tag": "2",},
    {"name":"Training plan", "image":"assets/img/clipboard.png", "tag": "3",},
    {"name":"Training status", "image":"assets/img/signal.png", "tag": "4",},
    {"name":"Meal Plan", "image":"assets/img/spoon.png", "tag": "5",},
    {"name":"Schedule", "image":"assets/img/calendar.png", "tag": "6",},

    {"name":"Running", "image":"assets/img/power.png", "tag": "7",},
    {"name":"Exercise", "image":"assets/img/work.png", "tag": "8",},
    {"name":"Tips", "image":"assets/img/light.png", "tag": "9",},
    {"name":"Settings", "image":"assets/img/settings.png", "tag": "10",},
    {"name":"Support", "image":"assets/img/que.png", "tag": "11",},


  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.sizeOf(context);
    return Scaffold(
      drawer: Drawer(
        width: media.width,
        backgroundColor: Colors.transparent,
        child: BackdropFilter(
          filter:ImageFilter.blur(
            sigmaX: 5,
            sigmaY: 5

          ),
          child: Stack(
            children: [
              Container(
                width: media.width * 0.78,
                decoration: BoxDecoration(color: TColor.white),
             child: SafeArea(
                 child: Padding(
                   padding: const EdgeInsets.only(left: 25),
                   child: Column(
                                children: [
                    Container(
                     height: kToolbarHeight,
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius:  BorderRadius.circular(22.5),
                            child: Image.asset("assets/img/u1.png",
                            width: 45,
                              height: 45,
                              fit: BoxFit.cover,
                            ),
                          ),
          
                          const SizedBox(
                            width: 20,
                          ),
          
                          Expanded(
                              child: Text("Training Plan",
                              style: TextStyle(
                                fontSize: 20,
                                color: TColor.sceondarText,
                                fontWeight: FontWeight.w700
                              ),
                              ))
                        ],
                      ),
                   ),
                 const SizedBox(
                height: 14,
                   ),
          
                   const Divider(
                     color: Colors.black26,
                     height: 1,
                   ),
          
                   Expanded(child:
                   ListView.builder(
                     padding: EdgeInsets.symmetric(vertical: 50),
                     itemCount: planArr.length,
                       itemBuilder: (context, index){
                       var itemObj = planArr[index] as Map ?? {};
                       return PlanRow(
                         mObj: itemObj,
                         onPressed: (){
                         //  Navigator.pop(context);
                           if(index ==1){
                             Navigator.push(
                                 context, MaterialPageRoute(
                                 builder: (context)=> const YogaView()));
                           }
                         },
          
          
                       );
          
                       }),
                   ),
          
          
                   const Divider(
                     color: Colors.black26,
                    height: 1,
                   ),
                                  const SizedBox(
                                    width: 15,
                                  ),
                                  Container(
                                    height: kToolbarHeight,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text("Switch Account",
                                              style: TextStyle(
                                                  fontSize: 18,
                                                  color: TColor.sceondarText,
                                                  fontWeight: FontWeight.w700
                                              ),
                                            ),
          
                                          Padding(
                                            padding: const EdgeInsets.only(right: 20),
                                            child: Image.asset("assets/img/rightarrow.png",
                                            width: 18, height: 18, fit: BoxFit.cover,
          
                                            ),
                                          )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                 )),
              ),
          
              Column(
                children: [
          
                 const SizedBox(height: kToolbarHeight - 25,),
                 Row(
                   mainAxisAlignment: MainAxisAlignment.end,
                   children: [
          
                     Padding(
                       padding: const EdgeInsets.only(right: 15),
                       child: IconButton(
                           onPressed: (){
                             Navigator.pop(context);
          
          
                           },
                           icon: Image.asset("assets/img/menu.png",
                             color: Colors.white,
                             width: 25, height: 25,)),
                     )
                   ],
                 )
                ],
              )
            ],
          ),
        ),

      ),
      body: NestedScrollView(headerSliverBuilder:
          (context, innerBoxIsScrolled){

        return[
          
             SliverAppBar(
               backgroundColor: Colors.black,
               expandedHeight: media.width * 0.6,
             //  collapsedHeight: kToolbarHeight * 20,
               flexibleSpace: Stack(
                 alignment: Alignment.bottomLeft,
                 children: [
                   Image.asset("assets/img/1.png",
                     width: media.width,
                     height:  media.width * 0.8,
                   fit: BoxFit.cover,
                   ),

                   Container(
                     width: media.width,
                     height: media.width * 0.8,
                     decoration: const BoxDecoration(
                       gradient: LinearGradient(colors: [Colors.transparent, Colors.black],
                       begin: Alignment.topCenter, end: Alignment.bottomCenter
                       )
                     ),
                   ),

                   Padding(
                     padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 30),
                     child: Row(
                       children: [
                         Container(
                            width:  54,
                             height: 54,
                           decoration:BoxDecoration(
                             color: TColor.white,
                             borderRadius: BorderRadius.circular(27)
                           ),
                           alignment: Alignment.center,
                           child: ClipRRect(
                             borderRadius: BorderRadius.circular(25),
                             child: Image.asset("assets/img/u1.png", width: 50,height: 50,
                             fit: BoxFit.cover,
                             ),
                           ),
                         ),

                         const SizedBox(width: 15,),
                         Expanded(
                           child: Column(
                             crossAxisAlignment: CrossAxisAlignment.start,
                             mainAxisSize: MainAxisSize.min,

                           children: [
                             Text("Code For Any", style: TextStyle(
                                 fontSize: 20,
                                 color: TColor.white,
                                 fontWeight: FontWeight.w700
                             ),),

                             const SizedBox(height: 4,),

                             Text("Profile", style: TextStyle(
                                 fontSize: 15,
                                 color: TColor.white,
                                 fontWeight: FontWeight.w500
                             ),)

                           ],
                           ),
                         ),
                       ],
                     ),
                   )


                 ],
               ),
             )

        ];

      }, body: GridView.builder(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
          gridDelegate: const
      SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing:15,
          mainAxisSpacing: 15,
            childAspectRatio: 1
      ),

          itemCount: menuArr.length,
          itemBuilder: ((context,index){
            var mObj = menuArr[index] as Map ?? {};

            return MenuCell(
              mObj:mObj,
              onPressed: (){
                switch(mObj["tag"].toString()){
                  case "1":
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const HomeView()));
                    break;

                  case "2":
                    Navigator.push(context, MaterialPageRoute(
                        builder: (context) => const WeightView()));
                    break;

                  case "3":
                    Scaffold.of(context).openDrawer();
                    break;

                    default:

                }


            },);
          }) )),
    );
  }
}
