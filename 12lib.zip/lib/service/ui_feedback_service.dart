import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

/// Reliable lightweight tactile + audible feedback for onboarding rulers.
/// Uses an app asset instead of Android SystemSound, which can be silent on
/// some MIUI/Redmi devices when touch sounds are disabled.
class UiFeedbackService {
  UiFeedbackService._();

  static final AudioPlayer _player = AudioPlayer();
  static DateTime _lastPlayed = DateTime.fromMillisecondsSinceEpoch(0);
  static const Duration _minimumGap = Duration(milliseconds: 45);

  static Future<void> tick() async {
    final now = DateTime.now();
    if (now.difference(_lastPlayed) < _minimumGap) return;
    _lastPlayed = now;

    HapticFeedback.selectionClick();

    try {
      await _player.play(
        AssetSource('sounds/ui_tick.wav'),
        volume: 0.55,
        mode: PlayerMode.lowLatency,
      );
    } catch (_) {
      // Haptic feedback still works if audio is unavailable.
    }
  }

  static Future<void> dispose() => _player.dispose();
}
