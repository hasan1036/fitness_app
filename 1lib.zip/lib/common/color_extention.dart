import 'package:flutter/material.dart';


class TColor {
  static Color get primary => const Color(0xff400259);
  static Color get primaryText => const Color(0xff000000);
  static Color get sceondarText => const Color(0xff707070);
  static Color get white => Colors.white;
  static Color get grey => const Color(0xff8C8C8C);
  static Color get green => const Color(0xff34e622);
  static Color get divider => const Color(0xffE1E1E1);

}